@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or not in PATH.
  echo Install Node.js 20 or newer, including npm, from https://nodejs.org/en/download
  start "" "https://nodejs.org/en/download"
  pause
  exit /b 1
)
echo Checking Node.js and npm...
node scripts\build.js --diagnose
if errorlevel 1 goto build_failed
node scripts\build.js
set "BUILD_EXIT=%ERRORLEVEL%"
if not "%BUILD_EXIT%"=="0" goto build_failed
echo.
echo Installer successfully created in the dist folder.
echo The dist folder will open now. Run the Setup EXE from there.
if exist "%~dp0dist" explorer.exe "%~dp0dist"
pause
exit /b 0
:build_failed
echo.
echo Windows installer build failed. No new installer was created.
echo Read the error above. Do not use an older Setup EXE by mistake.
pause
exit /b 1
