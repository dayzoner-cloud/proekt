// ==UserScript==
// @name         Проверка менеджера скриптов
// @name:ru      Проверка менеджера скриптов
// @description  Показывает небольшую метку, подтверждающую запуск скрипта в выбранном аккаунте.
// @match        https://youandme.chat/*
// @match        https://www.youandme.chat/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(() => {
  'use strict';
  const id = '__chvdMultiChatCustomScriptDemo';
  if (document.getElementById(id)) return;

  const badge = document.createElement('div');
  badge.id = id;
  badge.textContent = 'Пользовательский скрипт ЧатВдвоем++ работает';
  Object.assign(badge.style, {
    position: 'fixed',
    left: '10px',
    bottom: '10px',
    zIndex: '2147483646',
    padding: '7px 10px',
    border: '1px solid rgba(100, 170, 255, .5)',
    borderRadius: '8px',
    background: 'rgba(22, 39, 61, .92)',
    color: '#eaf3ff',
    font: '12px/1.3 Segoe UI, Arial, sans-serif',
    pointerEvents: 'none'
  });
  (document.body || document.documentElement).appendChild(badge);
})();
