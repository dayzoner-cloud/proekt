@echo off
setlocal
cd /d "%~dp0"
set "VERSION=0.1.8"
for /f "delims=" %%V in ('node -p "require('./package.json').version" 2^>nul') do set "VERSION=%%V"
set "SETUP=%~dp0dist\ChatVdvoem_Setup_%VERSION%.exe"
set "LOG=%TEMP%\ChatVdvoem_Setup_%VERSION%.log"
if not exist "%SETUP%" (
  echo Installer not found: "%SETUP%"
  echo Build the installer first with BUILD_EXE.bat.
  pause
  exit /b 1
)
echo Running the installer directly with verbose NSIS logging...
echo Log file: "%LOG%"
echo.
"%SETUP%" /LOG="%LOG%"
set "SETUP_EXIT=%ERRORLEVEL%"
echo.
echo Installer process exit code: %SETUP_EXIT%
if exist "%LOG%" (
  echo Opening installer log...
  notepad.exe "%LOG%"
) else (
  echo No NSIS log was created. NSIS did not start.
  echo Check Windows Security - Protection history and SmartScreen.
  echo The installer is unsigned; Windows may block it before the setup window appears.
  start "" "windowsdefender://threat/"
  pause
)
exit /b %SETUP_EXIT%
