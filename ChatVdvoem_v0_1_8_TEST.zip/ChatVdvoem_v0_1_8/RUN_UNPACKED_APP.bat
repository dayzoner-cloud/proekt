@echo off
setlocal
set "APP=%~dp0dist\win-unpacked\ChatVdvoem++.exe"
if not exist "%APP%" (
  echo Packaged application not found: "%APP%"
  echo Run BUILD_EXE.bat first and wait for BUILD SUCCESS.
  pause
  exit /b 1
)
start "" "%APP%"
exit /b 0
