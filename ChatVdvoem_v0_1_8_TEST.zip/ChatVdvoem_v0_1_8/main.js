'use strict';

const {
  app,
  BrowserWindow,
  WebContentsView,
  session,
  ipcMain,
  dialog,
  shell,
  safeStorage
} = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { parseUserScript, scriptMatchesUrl } = require('./scripts/custom-script-utils');

const SITE_URL = 'https://youandme.chat/';
const SITE_HOSTS = new Set(['youandme.chat', 'www.youandme.chat']);
const HEADER_HEIGHT = 48;
const FOOTER_HEIGHT = 28;
const PANE_HEADER_HEIGHT = 28;
const GRID_GAP = 8;
const ACCOUNT_IDS = [1, 2, 3, 4];

let mainWindow = null;
let scriptManagerWindow = null;
let visibleCount = 3;
let accountViews = new Map();
let accountMeta = {
  1: { label: 'Аккаунт 1', autoFill: false },
  2: { label: 'Аккаунт 2', autoFill: false },
  3: { label: 'Аккаунт 3', autoFill: false },
  4: { label: 'Аккаунт 4', autoFill: false }
};
let accountStatus = {};
let statusTimer = null;
let saveTimer = null;
let permissionGrants = new Map();
// User-approved filesystem roots are scoped to each isolated account session.
const approvedFileRoots = new Map();
let pollingStatuses = false;
const configuredSessions = new WeakSet();

const userDataDir = app.getPath('userData');
const settingsPath = path.join(userDataDir, 'multichat-settings.json');
const vaultPath = path.join(userDataDir, 'accounts-vault.json');
const diagnosticsPath = path.join(userDataDir, 'multichat-diagnostics.log');
const customScriptsDir = path.join(userDataDir, 'custom-scripts');
const customScriptsManifestPath = path.join(userDataDir, 'custom-scripts.json');
const MAX_CUSTOM_SCRIPT_BYTES = 2 * 1024 * 1024;
let vault = { accounts: {} };
let customScripts = [];

function logDiagnostic(message, details = null) {
  try {
    fs.mkdirSync(userDataDir, { recursive: true });
    const suffix = details == null ? '' : ` ${typeof details === 'string' ? details : JSON.stringify(details)}`;
    fs.appendFileSync(diagnosticsPath, `[${new Date().toISOString()}] ${message}${suffix}\r\n`, 'utf8');
  } catch {}
}

function getTrustedRequestOrigin(requestingOrigin, details = {}, webContents = null) {
  // Never fall back to the top-level URL when a subframe explicitly reports an
  // untrusted origin. That prevents an embedded third-party frame from inheriting
  // YouAndMe's File System Access permission.
  const explicit = [requestingOrigin, details?.securityOrigin, details?.requestingUrl]
    .find(value => typeof value === 'string' && value.trim());
  if (explicit) {
    if (!isTrustedOrigin(explicit)) return '';
    try { return new URL(explicit).origin; } catch { return ''; }
  }
  const fallback = webContents?.getURL?.();
  if (isTrustedOrigin(fallback)) {
    try { return new URL(fallback).origin; } catch {}
  }
  return '';
}

function safeReadJson(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const value = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return value && typeof value === 'object' ? value : fallback;
  } catch {
    return fallback;
  }
}

function writeJsonAtomic(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tempPath = `${filePath}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(value, null, 2), { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(tempPath, filePath);
}


function saveCustomScriptsManifest() {
  writeJsonAtomic(customScriptsManifestPath, {
    version: 1,
    scripts: customScripts.map(({ id, name, description, originalName, enabled, accounts, matchPatterns, excludePatterns, grants, warnings, sha256, addedAt }) => ({
      id, name, description, originalName, enabled, accounts, matchPatterns, excludePatterns, grants, warnings, sha256, addedAt
    }))
  });
}

function loadCustomScripts() {
  fs.mkdirSync(customScriptsDir, { recursive: true });
  const stored = safeReadJson(customScriptsManifestPath, { scripts: [] });
  const entries = Array.isArray(stored.scripts) ? stored.scripts : [];
  customScripts = entries.filter(item => {
    if (!item || typeof item.id !== 'string' || !/^[a-f0-9-]{36}$/i.test(item.id)) return false;
    const filePath = path.join(customScriptsDir, `${item.id}.js`);
    if (!fs.existsSync(filePath)) return false;
    return true;
  }).map(item => ({
    id: item.id,
    name: String(item.name || item.originalName || 'Пользовательский скрипт').slice(0, 100),
    description: String(item.description || '').slice(0, 240),
    originalName: String(item.originalName || `${item.id}.js`).slice(0, 180),
    enabled: item.enabled !== false,
    accounts: Array.isArray(item.accounts) ? [...new Set(item.accounts.map(Number).filter(id => ACCOUNT_IDS.includes(id)))] : [1],
    matchPatterns: Array.isArray(item.matchPatterns) ? item.matchPatterns.map(String).slice(0, 20) : [],
    excludePatterns: Array.isArray(item.excludePatterns) ? item.excludePatterns.map(String).slice(0, 20) : [],
    grants: Array.isArray(item.grants) ? item.grants.map(String).slice(0, 30) : [],
    warnings: Array.isArray(item.warnings) ? item.warnings.map(String).slice(0, 20) : [],
    sha256: String(item.sha256 || ''),
    addedAt: String(item.addedAt || '')
  }));
  if (customScripts.length !== entries.length) saveCustomScriptsManifest();
}

function customScriptFilePath(id) {
  if (!/^[a-f0-9-]{36}$/i.test(String(id))) throw new Error('Некорректный идентификатор скрипта.');
  return path.join(customScriptsDir, `${id}.js`);
}

function getCustomScriptsPublic() {
  return customScripts.map(item => ({
    id: item.id,
    name: item.name,
    description: item.description,
    originalName: item.originalName,
    enabled: item.enabled,
    accounts: [...item.accounts],
    matchPatterns: [...item.matchPatterns],
    excludePatterns: [...(item.excludePatterns || [])],
    grants: [...item.grants],
    warnings: [...item.warnings],
    addedAt: item.addedAt
  }));
}

function getScriptManagerDialogParent() {
  return scriptManagerWindow && !scriptManagerWindow.isDestroyed() ? scriptManagerWindow : mainWindow;
}

async function confirmScriptTrust(title, detail) {
  const answer = await dialog.showMessageBox(getScriptManagerDialogParent(), {
    type: 'warning',
    title: 'Подтверждение пользовательского JavaScript',
    message: `Установить скрипт «${title}»?`,
    detail: `${detail}\n\nСкрипт выполняется внутри страницы YouAndMe и может читать доступные ей данные аккаунта, включая содержимое чата и GUID, а также отправлять данные через доступные странице сетевые API. Он не получает Node.js API и прямой доступ к файлам компьютера. Устанавливай только код, которому доверяешь.`,
    buttons: ['Установить', 'Отмена'],
    defaultId: 1,
    cancelId: 1,
    noLink: true
  });
  return answer.response === 0;
}

function addCustomScriptRecord(source, originalName, options = {}) {
  const metadata = parseUserScript(source, originalName);
  const sha256 = crypto.createHash('sha256').update(source, 'utf8').digest('hex');
  const duplicate = customScripts.find(item => item.sha256 === sha256);
  if (duplicate) throw new Error(`Этот скрипт уже установлен: «${duplicate.name}».`);
  const id = crypto.randomUUID();
  const filePath = customScriptFilePath(id);
  fs.mkdirSync(customScriptsDir, { recursive: true });
  fs.writeFileSync(filePath, source, { encoding: 'utf8', flag: 'wx', mode: 0o600 });
  const accounts = Array.isArray(options.accounts)
    ? [...new Set(options.accounts.map(Number).filter(accountId => ACCOUNT_IDS.includes(accountId)))]
    : [1];
  const record = {
    id,
    name: String(options.name || metadata.name).slice(0, 100),
    description: String(options.description || metadata.description).slice(0, 240),
    originalName: path.basename(String(originalName || `${id}.js`)).slice(0, 180),
    enabled: options.enabled !== false,
    accounts: accounts.length ? accounts : [1],
    matchPatterns: metadata.matchPatterns,
    excludePatterns: metadata.excludePatterns,
    grants: metadata.grants,
    warnings: metadata.warnings,
    sha256,
    addedAt: new Date().toISOString()
  };
  customScripts.push(record);
  saveCustomScriptsManifest();
  return record;
}

async function injectCustomScriptsForAccount(accountId, onlyScriptId = null) {
  const view = accountViews.get(accountId);
  if (!view || view.webContents.isDestroyed()) return [];
  const url = view.webContents.getURL();
  if (!isTrustedSiteUrl(url)) return [];
  const injected = [];
  const candidates = customScripts.filter(item => item.enabled && item.accounts.includes(accountId) && (!onlyScriptId || item.id === onlyScriptId) && scriptMatchesUrl(item, url));
  for (const item of candidates) {
    try {
      const source = fs.readFileSync(customScriptFilePath(item.id), 'utf8');
      const marker = `__chvdCustomScript_${item.id.replace(/-/g, '')}`;
      const label = item.name.replace(/[\r\n]/g, ' ').slice(0, 80);
      const wrapper = `(() => {
        if (window.top !== window || !['youandme.chat','www.youandme.chat'].includes(location.hostname)) return;
        const marker = ${JSON.stringify(marker)};
        if (window[marker]) return;
        window[marker] = true;
        try {
          const unsafeWindow = window;
          ${source}\n
        } catch (error) {
          console.error('[ЧатВдвоем++ script: ${label}]', error);
          throw error;
        }
      })();\n//# sourceURL=chvd-custom-${item.id}.js`;
      await view.webContents.executeJavaScript(wrapper, false);
      injected.push(item.id);
      logDiagnostic(`Custom script injected (account ${accountId})`, { id: item.id, name: item.name });
    } catch (error) {
      logDiagnostic(`Custom script injection failed (account ${accountId})`, { id: item.id, name: item.name, error: error?.stack || error?.message || String(error) });
    }
  }
  return injected;
}

function loadSettings() {
  const stored = safeReadJson(settingsPath, {});
  visibleCount = Number.isInteger(stored.visibleCount) ? Math.max(1, Math.min(4, stored.visibleCount)) : 3;
  if (stored.accounts && typeof stored.accounts === 'object') {
    for (const id of ACCOUNT_IDS) {
      const item = stored.accounts[id] || {};
      accountMeta[id] = {
        label: typeof item.label === 'string' && item.label.trim() ? item.label.trim().slice(0, 32) : `Аккаунт ${id}`,
        autoFill: item.autoFill === true
      };
    }
  }
  vault = safeReadJson(vaultPath, { accounts: {} });
  if (!vault.accounts || typeof vault.accounts !== 'object') vault = { accounts: {} };
}

function saveSettings() {
  try {
    writeJsonAtomic(settingsPath, {
      version: 1,
      visibleCount,
      accounts: accountMeta
    });
  } catch (error) {
    console.error('[ЧатВдвоем++] Не удалось сохранить настройки:', error.message);
  }
}

function saveVault() {
  writeJsonAtomic(vaultPath, vault);
}

function isTrustedSiteUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === 'https:' && SITE_HOSTS.has(parsed.hostname);
  } catch {
    return false;
  }
}

function isTrustedOrigin(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === 'https:' && SITE_HOSTS.has(parsed.hostname);
  } catch {
    return false;
  }
}

function emitStatus(id, patch) {
  const current = accountStatus[id] || { id, state: 'inactive', title: '', url: '', guidTail: '' };
  accountStatus[id] = { ...current, ...patch, id };
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('account-status', accountStatus[id]);
  }
}

function getAccountPublicState(id) {
  const item = accountMeta[id] || { label: `Аккаунт ${id}`, autoFill: false };
  const credentialRecord = vault.accounts[id];
  const hasCredentials = !!credentialRecord?.usernameEnc && !!credentialRecord?.passwordEnc;
  let username = '';
  if (credentialRecord?.usernameEnc && safeStorage.isEncryptionAvailable()) {
    try { username = safeStorage.decryptString(Buffer.from(credentialRecord.usernameEnc, 'base64')); } catch {}
  }
  return {
    id,
    label: item.label,
    autoFill: item.autoFill,
    hasCredentials,
    username,
    status: accountStatus[id] || { id, state: 'inactive', title: '', url: '', guidTail: '' },
    opened: accountViews.has(id)
  };
}

function getPublicState() {
  return {
    visibleCount,
    safeStorageAvailable: safeStorage.isEncryptionAvailable(),
    accounts: ACCOUNT_IDS.map(getAccountPublicState)
  };
}

function setCount(nextCount) {
  if (!Number.isInteger(nextCount) || nextCount < 1 || nextCount > 4) {
    throw new Error('Количество аккаунтов должно быть от 1 до 4.');
  }
  visibleCount = nextCount;
  saveSettings();
  if (accountViews.size > 0) {
    for (const id of [...accountViews.keys()]) {
      if (id > visibleCount) destroyAccountView(id);
    }
    for (let id = 1; id <= visibleCount; id++) {
      if (!accountViews.has(id)) createAccountView(id);
    }
    layoutViews();
  }
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('app-state', getPublicState());
  }
  return getPublicState();
}

function isPathInside(rootPath, targetPath) {
  if (!rootPath || !targetPath) return false;
  try {
    const root = path.resolve(rootPath);
    const target = path.resolve(targetPath);
    const relative = path.relative(root, target);
    return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
  } catch {
    return false;
  }
}

function getApprovedFileRoots(accountId) {
  if (!approvedFileRoots.has(accountId)) approvedFileRoots.set(accountId, new Set());
  return approvedFileRoots.get(accountId);
}

function configureSession(accountSession, accountId) {
  if (configuredSessions.has(accountSession)) return;
  configuredSessions.add(accountSession);

  accountSession.setPermissionCheckHandler((webContents, permission, requestingOrigin, details = {}) => {
    const origin = getTrustedRequestOrigin(requestingOrigin, details, webContents);
    const key = `${accountId}:${permission}:${origin}`;
    if (permission === 'media') return permissionGrants.get(key) === true;
    // The site must be trusted, but the folder itself is still selected by the
    // user in Chromium's picker. Writable File System API access is not needed.
    if (permission === 'fileSystem') {
      return !!origin && (!details?.fileAccessType || details.fileAccessType === 'readable');
    }
    if (permission === 'fullscreen') return !!origin;
    if (permission === 'clipboard-sanitized-write') return !!origin;
    return false;
  });

  accountSession.setPermissionRequestHandler(async (webContents, permission, callback, details = {}) => {
    const origin = getTrustedRequestOrigin(details.requestingUrl, details, webContents);
    if (!origin) {
      if (permission === 'fileSystem') logDiagnostic(`FS permission denied for untrusted origin (account ${accountId})`, { permission, requestingUrl: details.requestingUrl || webContents.getURL() });
      return callback(false);
    }

    if (permission === 'fileSystem') {
      const accessType = details.fileAccessType || 'readable';
      if (accessType !== 'readable') {
        logDiagnostic(`FS write access denied (account ${accountId})`, { origin, accessType, filePath: details.filePath || '' });
        return callback(false);
      }
      permissionGrants.set(`${accountId}:fileSystem:${origin}`, true);
      logDiagnostic(`FS read permission granted (account ${accountId})`, { origin, filePath: details.filePath || '', isDirectory: details.isDirectory === true });
      return callback(true);
    }

    if (permission === 'media') {
      const key = `${accountId}:${permission}:${origin}`;
      if (permissionGrants.get(key) === true) return callback(true);
      if (permissionGrants.get(key) === false) return callback(false);
      const mediaTypes = Array.isArray(details.mediaTypes) ? details.mediaTypes : [];
      const requested = mediaTypes.length ? mediaTypes.join(' + ') : 'камера/микрофон';
      const answer = await dialog.showMessageBox(mainWindow, {
        type: 'question',
        title: `Разрешение устройств — аккаунт ${accountId}`,
        message: `YouAndMe запрашивает доступ к устройствам: ${requested}.`,
        detail: `Разрешение действует для отдельной сессии аккаунта ${accountId}. Другие аккаунты приложения не получают этот доступ автоматически.`,
        buttons: ['Разрешить', 'Запретить'],
        defaultId: 0,
        cancelId: 1,
        noLink: true
      });
      const allowed = answer.response === 0;
      permissionGrants.set(key, allowed);
      return callback(allowed);
    }

    if (permission === 'fullscreen') return callback(true);
    if (permission === 'clipboard-sanitized-write') return callback(true);
    if (permission === 'notifications') return callback(true);
    return callback(false);
  });

  // Electron may block access to sensitive Windows locations even after the
  // user has chosen a folder. Require an explicit approval for that selected
  // root and keep the approval isolated to this account's session.
  accountSession.on('file-system-access-restricted', async (_event, details, callback) => {
    let completed = false;
    const finish = (action) => {
      if (completed) return;
      completed = true;
      try { callback(action); } catch {}
    };

    try {
      const origin = String(details?.origin || '');
      const targetPath = String(details?.path || '');
      const ownerView = accountViews.get(accountId);
      if (details?.webContents && ownerView && details.webContents !== ownerView.webContents) {
        logDiagnostic(`FS restricted request came from unexpected WebContents (account ${accountId})`, { origin, targetPath });
        finish('deny');
        return;
      }
      if (!isTrustedOrigin(origin) || !targetPath || !path.isAbsolute(targetPath)) {
        logDiagnostic(`FS restricted request denied (account ${accountId})`, { origin, targetPath });
        finish('deny');
        return;
      }

      const roots = getApprovedFileRoots(accountId);
      for (const root of roots) {
        if (isPathInside(root, targetPath)) {
          logDiagnostic(`FS restricted path allowed from approved root (account ${accountId})`, { targetPath });
          finish('allow');
          return;
        }
      }

      if (!mainWindow || mainWindow.isDestroyed()) {
        logDiagnostic(`FS restricted request denied because app window is closed (account ${accountId})`, { targetPath });
        finish('deny');
        return;
      }

      logDiagnostic(`FS restricted path requires confirmation (account ${accountId})`, { targetPath, isDirectory: details.isDirectory === true });
      const answer = await dialog.showMessageBox(mainWindow, {
        type: 'question',
        title: `Доступ к выбранной папке — аккаунт ${accountId}`,
        message: 'ЧатВдвоем++ запрашивает доступ к выбранной папке.',
        detail: `Путь: ${targetPath}\n\nРазрешение действует только для аккаунта ${accountId}. Разрешайте доступ, если это папка, которую вы сами только что выбрали в окне выбора файлов.`,
        buttons: ['Разрешить этой папке', 'Запретить'],
        defaultId: 1,
        cancelId: 1,
        noLink: true
      });

      if (answer.response === 0) {
        roots.add(path.resolve(details.isDirectory ? targetPath : path.dirname(targetPath)));
        logDiagnostic(`FS restricted path approved (account ${accountId})`, { targetPath });
        finish('allow');
      } else {
        logDiagnostic(`FS restricted path denied by user (account ${accountId})`, { targetPath });
        finish('deny');
      }
    } catch (error) {
      logDiagnostic(`FS restricted event failed (account ${accountId})`, { error: error?.stack || error?.message || String(error) });
      finish('deny');
    }
  });

  accountSession.on('will-download', async (_event, item, webContents) => {
    const suggested = path.join(app.getPath('downloads'), item.getFilename());
    const answer = await dialog.showSaveDialog(mainWindow, {
      title: `Сохранить файл — аккаунт ${accountId}`,
      defaultPath: suggested,
      buttonLabel: 'Сохранить'
    });
    if (answer.canceled || !answer.filePath) item.cancel();
    else item.setSavePath(answer.filePath);
  });
}

function createPageView(accountId) {
  const partition = `persist:chvd-multichat-account-${accountId}`;
  const accountSession = session.fromPartition(partition);
  configureSession(accountSession, accountId);

  const view = new WebContentsView({
    webPreferences: {
      session: accountSession,
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      backgroundThrottling: false,
      spellcheck: true
    }
  });

  const wc = view.webContents;
  wc.setBackgroundThrottling(false);
  wc.on('console-message', (_event, details) => {
    const level = Number(details?.level ?? 0);
    if (level >= 2) {
      logDiagnostic(`Page console error (account ${accountId})`, {
        message: String(details?.message || '').slice(0, 1000),
        sourceId: String(details?.sourceId || '').slice(0, 300),
        lineNumber: details?.lineNumber
      });
    }
  });
  wc.setWindowOpenHandler(({ url }) => {
    if (isTrustedSiteUrl(url)) {
      setTimeout(() => {
        if (!wc.isDestroyed()) wc.loadURL(url).catch(() => {});
      }, 0);
    } else {
      shell.openExternal(url).catch(() => {});
    }
    return { action: 'deny' };
  });

  wc.on('page-title-updated', (event, title) => {
    event.preventDefault();
    emitStatus(accountId, { title: String(title || '').slice(0, 80) });
  });

  wc.on('did-start-loading', () => emitStatus(accountId, { state: 'loading' }));
  wc.on('did-finish-load', () => {
    emitStatus(accountId, { state: 'loaded', url: wc.getURL() });
    if (accountMeta[accountId]?.autoFill) {
      setTimeout(() => installAutoFillWatcher(accountId).catch(() => {}), 650);
    }
  });
  wc.on('did-navigate', (_event, url) => emitStatus(accountId, { url, state: 'loaded' }));
  wc.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL, isMainFrame) => {
    if (isMainFrame && errorCode !== -3) {
      logDiagnostic(`Page load failed (account ${accountId})`, { errorCode, errorDescription, url: validatedURL });
      emitStatus(accountId, { state: 'error', error: `${errorDescription} (${errorCode})`, url: validatedURL });
    }
  });

  // Inject only scripts explicitly added through the built-in script manager.
  wc.on('dom-ready', async () => {
    if (wc.isDestroyed() || !isTrustedSiteUrl(wc.getURL())) return;
    await injectCustomScriptsForAccount(accountId);
  });

  wc.on('render-process-gone', (_event, details) => {
    emitStatus(accountId, { state: 'crashed', error: details?.reason || 'Рендерер завершился' });
  });

  return view;
}

function createAccountView(id) {
  if (!mainWindow || mainWindow.isDestroyed() || accountViews.has(id)) return;
  const view = createPageView(id);
  accountViews.set(id, view);
  mainWindow.contentView.addChildView(view);
  layoutViews();
  emitStatus(id, { state: 'loading', title: '', url: SITE_URL, error: '' });
  view.webContents.loadURL(SITE_URL).catch((error) => {
    emitStatus(id, { state: 'error', error: error.message || 'Не удалось открыть YouAndMe' });
  });
}

function destroyAccountView(id) {
  const view = accountViews.get(id);
  if (!view) return;
  accountViews.delete(id);
  try { mainWindow?.contentView.removeChildView(view); } catch {}
  try { if (!view.webContents.isDestroyed()) view.webContents.close(); } catch {}
  emitStatus(id, { state: 'inactive', title: '', url: '', guidTail: '', error: '' });
}

function layoutViews() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const [contentWidth, contentHeight] = mainWindow.getContentSize();
  const width = Math.max(360, contentWidth);
  const workspaceHeight = Math.max(180, contentHeight - HEADER_HEIGHT - FOOTER_HEIGHT);
  const count = accountViews.size;
  if (!count) {
    mainWindow.webContents.send('pane-layout', []);
    return;
  }

  let columns = count === 1 ? 1 : count === 2 ? 2 : count === 3 ? (width >= 1450 ? 3 : 2) : 2;
  const rows = Math.ceil(count / columns);
  const rowHeight = (workspaceHeight - GRID_GAP * (rows - 1)) / rows;
  const cellWidth = (width - GRID_GAP * (columns - 1)) / columns;
  const layout = [];

  for (let index = 0; index < count; index++) {
    const id = [...accountViews.keys()].sort((a, b) => a - b)[index];
    const view = accountViews.get(id);
    if (!view) continue;

    let col = index % columns;
    let row = Math.floor(index / columns);
    let span = 1;
    if (count === 3 && columns === 2 && index === 2) {
      col = 0;
      row = 1;
      span = 2;
    }

    const x = Math.round(col * (cellWidth + GRID_GAP));
    const paneWidth = Math.round(cellWidth * span + GRID_GAP * (span - 1));
    const headerY = Math.round(HEADER_HEIGHT + row * (rowHeight + GRID_GAP));
    const paneHeight = Math.round(rowHeight);
    const bodyY = headerY + PANE_HEADER_HEIGHT;
    const bodyHeight = Math.max(100, paneHeight - PANE_HEADER_HEIGHT);

    view.setBounds({
      x: x + 1,
      y: bodyY,
      width: Math.max(100, paneWidth - 2),
      height: bodyHeight
    });
    view.setVisible(true);
    layout.push({ id, x, y: headerY - HEADER_HEIGHT, width: paneWidth, headerHeight: PANE_HEADER_HEIGHT, height: paneHeight });
  }
  mainWindow.webContents.send('pane-layout', layout);
}

async function installAutoFillWatcher(id) {
  const view = accountViews.get(id);
  const record = vault.accounts[id];
  if (!view || view.webContents.isDestroyed() || !accountMeta[id]?.autoFill || !record?.usernameEnc || !record?.passwordEnc) return false;
  if (!safeStorage.isEncryptionAvailable()) return false;
  let username;
  let password;
  try {
    username = safeStorage.decryptString(Buffer.from(record.usernameEnc, 'base64'));
    password = safeStorage.decryptString(Buffer.from(record.passwordEnc, 'base64'));
  } catch {
    return false;
  }
  const payload = JSON.stringify({ username, password });
  const script = `(() => {
    const marker = '__chvdMultiChatAutoFillWatcher';
    try { window[marker]?.disconnect?.(); } catch {}
    const credentials = ${payload};
    let finished = false;
    let observer = null;
    const fillIfReady = () => {
      if (finished) return true;
      const form = document.querySelector('#signin-form');
      const user = document.querySelector('#signin-phone') || form?.querySelector('input[name="username"]') || document.querySelector('input[name="username"]');
      const pass = form?.querySelector('input[type="password"]') || document.querySelector('.field-wrap input[type="password"]') || document.querySelector('input[type="password"]');
      if (!user || !pass) return false;
      const setValue = (el, value) => {
        const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
        if (setter) setter.call(el, value); else el.value = value;
        el.dispatchEvent(new Event('input', { bubbles:true }));
        el.dispatchEvent(new Event('change', { bubbles:true }));
      };
      setValue(user, credentials.username);
      setValue(pass, credentials.password);
      finished = true;
      try { observer?.disconnect(); } catch {}
      try { delete window[marker]; } catch {}
      return true;
    };
    observer = new MutationObserver(fillIfReady);
    window[marker] = observer;
    if (document.documentElement) observer.observe(document.documentElement, { childList:true, subtree:true });
    fillIfReady();
    setTimeout(() => { if (!finished) { try { observer.disconnect(); delete window[marker]; } catch {} } }, 60000);
    return true;
  })()`;
  await view.webContents.executeJavaScript(script, false);
  return true;
}

async function fillCredentialsIntoView(id, options = {}) {
  const view = accountViews.get(id);
  if (!view || view.webContents.isDestroyed()) throw new Error(`Окно аккаунта ${id} не запущено.`);
  if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows не предоставил доступ к защищённому хранилищу паролей. Введи данные непосредственно на сайте.');
  const record = vault.accounts[id];
  if (!record?.usernameEnc || !record?.passwordEnc) throw new Error(`Для аккаунта ${id} ещё не сохранены логин и пароль.`);

  let username;
  let password;
  try {
    username = safeStorage.decryptString(Buffer.from(record.usernameEnc, 'base64'));
    password = safeStorage.decryptString(Buffer.from(record.passwordEnc, 'base64'));
  } catch {
    throw new Error('Не удалось расшифровать сохранённые данные. Сохрани логин и пароль заново.');
  }

  const payload = JSON.stringify({ username, password });
  const script = `(() => {
    const creds = ${payload};
    const form = document.querySelector('#signin-form');
    const user = document.querySelector('#signin-phone') || form?.querySelector('input[name="username"]') || document.querySelector('input[name="username"]');
    const pass = form?.querySelector('input[type="password"]') || document.querySelector('.field-wrap input[type="password"]') || document.querySelector('input[type="password"]');
    if (!user || !pass) return { ok:false, reason:'form-not-found' };
    const setValue = (el, value) => {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
      if (setter) setter.call(el, value); else el.value = value;
      el.dispatchEvent(new Event('input', { bubbles:true }));
      el.dispatchEvent(new Event('change', { bubbles:true }));
    };
    setValue(user, creds.username);
    setValue(pass, creds.password);
    return { ok:true };
  })()`;
  const result = await view.webContents.executeJavaScript(script, false);
  if (!result?.ok) {
    if (!options.silent) throw new Error('Форма входа не найдена. Сначала открой на сайте форму авторизации, затем нажми «Заполнить».');
    return false;
  }
  return true;
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1580,
    height: 980,
    minWidth: 980,
    minHeight: 640,
    backgroundColor: '#10131a',
    title: 'ЧатВдвоем++',
    icon: path.join(__dirname, 'renderer', 'app-icon.ico'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      spellcheck: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  mainWindow.on('resize', layoutViews);
  mainWindow.on('maximize', layoutViews);
  mainWindow.on('unmaximize', layoutViews);
  mainWindow.on('closed', () => {
    if (scriptManagerWindow && !scriptManagerWindow.isDestroyed()) scriptManagerWindow.destroy();
    scriptManagerWindow = null;
    for (const id of [...accountViews.keys()]) destroyAccountView(id);
    mainWindow = null;
  });
}

function createScriptManagerWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) throw new Error('Главное окно ЧатВдвоем++ ещё не готово.');
  if (scriptManagerWindow && !scriptManagerWindow.isDestroyed()) {
    if (scriptManagerWindow.isMinimized()) scriptManagerWindow.restore();
    scriptManagerWindow.show();
    scriptManagerWindow.focus();
    return scriptManagerWindow;
  }

  scriptManagerWindow = new BrowserWindow({
    parent: mainWindow,
    modal: false,
    show: false,
    width: 960,
    height: 760,
    minWidth: 760,
    minHeight: 580,
    backgroundColor: '#10151f',
    title: 'ЧатВдвоем++ — Скрипты',
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'renderer', 'app-icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'script-manager-preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      spellcheck: false
    }
  });

  scriptManagerWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  scriptManagerWindow.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file://')) event.preventDefault();
  });
  scriptManagerWindow.webContents.on('did-fail-load', (_event, code, description, url) => {
    logDiagnostic('Script manager window failed to load', { code, description, url });
  });
  scriptManagerWindow.once('ready-to-show', () => {
    if (scriptManagerWindow && !scriptManagerWindow.isDestroyed()) {
      scriptManagerWindow.show();
      scriptManagerWindow.focus();
    }
  });
  scriptManagerWindow.on('closed', () => { scriptManagerWindow = null; });
  scriptManagerWindow.loadFile(path.join(__dirname, 'renderer', 'script-manager.html'))
    .catch(error => {
      logDiagnostic('Script manager load error', { error: error?.stack || error?.message || String(error) });
      if (scriptManagerWindow && !scriptManagerWindow.isDestroyed()) scriptManagerWindow.close();
    });
  return scriptManagerWindow;
}

function registerIpc() {
  ipcMain.handle('open-script-manager', () => { createScriptManagerWindow(); return true; });
  ipcMain.handle('close-script-manager', () => {
    if (scriptManagerWindow && !scriptManagerWindow.isDestroyed()) scriptManagerWindow.close();
    return true;
  });
  ipcMain.handle('get-state', () => getPublicState());
  ipcMain.handle('set-count', (_event, count) => setCount(count));
  ipcMain.handle('launch', () => {
    for (let id = 1; id <= visibleCount; id++) createAccountView(id);
    layoutViews();
    return getPublicState();
  });
  ipcMain.handle('close-chats', () => {
    for (const id of [...accountViews.keys()]) destroyAccountView(id);
    return getPublicState();
  });
  ipcMain.handle('reload-account', (_event, id) => {
    const view = accountViews.get(Number(id));
    if (!view) throw new Error('Это окно не запущено.');
    view.webContents.reload();
    return true;
  });
  ipcMain.handle('home-account', (_event, id) => {
    const view = accountViews.get(Number(id));
    if (!view) throw new Error('Это окно не запущено.');
    view.webContents.loadURL(SITE_URL);
    return true;
  });
  ipcMain.handle('devtools-account', (_event, id) => {
    const view = accountViews.get(Number(id));
    if (!view) throw new Error('Это окно не запущено.');
    view.webContents.openDevTools({ mode: 'detach' });
    return true;
  });
  ipcMain.handle('save-account-settings', (_event, id, data) => {
    const accountId = Number(id);
    if (!ACCOUNT_IDS.includes(accountId)) throw new Error('Неверный номер аккаунта.');
    const label = String(data?.label || `Аккаунт ${accountId}`).trim().slice(0, 32) || `Аккаунт ${accountId}`;
    const autoFill = data?.autoFill === true;
    accountMeta[accountId] = { label, autoFill };
    saveSettings();
    const currentView = accountViews.get(accountId);
    if (currentView && !currentView.webContents.isDestroyed()) {
      if (autoFill) setTimeout(() => installAutoFillWatcher(accountId).catch(() => {}), 0);
      else currentView.webContents.executeJavaScript("try { window.__chvdMultiChatAutoFillWatcher?.disconnect?.(); delete window.__chvdMultiChatAutoFillWatcher; } catch {}", false).catch(() => {});
    }
    return getAccountPublicState(accountId);
  });
  ipcMain.handle('save-credentials', (_event, id, data) => {
    const accountId = Number(id);
    if (!ACCOUNT_IDS.includes(accountId)) throw new Error('Неверный номер аккаунта.');
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Защищённое хранилище Windows недоступно. Пароль не сохранён.');
    const username = String(data?.username || '').trim();
    const password = String(data?.password || '');
    if (!username) throw new Error('Укажи логин.');
    const previous = vault.accounts[accountId] || {};
    if (!password && !previous.passwordEnc) throw new Error('Укажи пароль для первого сохранения.');
    const usernameEnc = safeStorage.encryptString(username).toString('base64');
    const passwordEnc = password ? safeStorage.encryptString(password).toString('base64') : previous.passwordEnc;
    vault.accounts[accountId] = { usernameEnc, passwordEnc };
    saveVault();
    return getAccountPublicState(accountId);
  });
  ipcMain.handle('clear-credentials', (_event, id) => {
    const accountId = Number(id);
    if (!ACCOUNT_IDS.includes(accountId)) throw new Error('Неверный номер аккаунта.');
    delete vault.accounts[accountId];
    saveVault();
    return getAccountPublicState(accountId);
  });
  ipcMain.handle('fill-credentials', (_event, id) => fillCredentialsIntoView(Number(id)));
  ipcMain.handle('open-diagnostics', async () => {
    if (!fs.existsSync(diagnosticsPath)) {
      fs.mkdirSync(path.dirname(diagnosticsPath), { recursive: true });
      fs.writeFileSync(diagnosticsPath, 'ChatVdvoem++ diagnostics\r\n', 'utf8');
    }
    const error = await shell.openPath(diagnosticsPath);
    if (error) throw new Error(error);
    return true;
  });
  ipcMain.handle('focus-account', (_event, id) => {
    const view = accountViews.get(Number(id));
    if (!view) throw new Error('Это окно не запущено.');
    view.webContents.focus();
    return true;
  });

  ipcMain.handle('get-custom-scripts', () => getCustomScriptsPublic());
  ipcMain.handle('import-custom-script', async () => {
    const result = await dialog.showOpenDialog(getScriptManagerDialogParent(), {
      title: 'Добавить пользовательский скрипт',
      properties: ['openFile'],
      filters: [{ name: 'JavaScript userscripts', extensions: ['js'] }]
    });
    if (result.canceled || !result.filePaths?.[0]) return { canceled: true, scripts: getCustomScriptsPublic() };
    const filePath = result.filePaths[0];
    const stat = fs.statSync(filePath);
    if (!stat.isFile() || stat.size < 1 || stat.size > MAX_CUSTOM_SCRIPT_BYTES) throw new Error('Файл должен быть от 1 байта до 2 МБ.');
    const source = fs.readFileSync(filePath, 'utf8');
    const metadata = parseUserScript(source, path.basename(filePath));
    const grantsNote = metadata.grants.length ? `\nЗаявленные @grant: ${metadata.grants.join(', ')}` : '';
    const warningNote = metadata.warnings.length ? `\nОсобенности: ${metadata.warnings.join('; ')}` : '';
    const approved = await confirmScriptTrust(metadata.name, `Файл: ${path.basename(filePath)}\nОписание: ${metadata.description || 'не указано'}\nСовпадение URL: ${metadata.matchPatterns.length ? metadata.matchPatterns.join(', ') : 'все страницы YouAndMe'}${grantsNote}${warningNote}`);
    if (!approved) return { canceled: true, scripts: getCustomScriptsPublic() };
    const record = addCustomScriptRecord(source, path.basename(filePath), { enabled: true, accounts: [1] });
    await injectCustomScriptsForAccount(1, record.id);
    logDiagnostic('Custom script imported', { id: record.id, name: record.name, sha256: record.sha256 });
    return { canceled: false, addedId: record.id, scripts: getCustomScriptsPublic() };
  });
  ipcMain.handle('update-custom-script', async (_event, id) => {
    const item = customScripts.find(script => script.id === String(id));
    if (!item) throw new Error('Скрипт не найден.');
    const result = await dialog.showOpenDialog(getScriptManagerDialogParent(), {
      title: `Выбрать новую версию скрипта «${item.name}»`,
      properties: ['openFile'],
      filters: [{ name: 'JavaScript userscripts', extensions: ['js'] }]
    });
    if (result.canceled || !result.filePaths?.[0]) return { canceled: true, scripts: getCustomScriptsPublic() };
    const sourcePath = result.filePaths[0];
    const stat = fs.statSync(sourcePath);
    if (!stat.isFile() || stat.size < 1 || stat.size > MAX_CUSTOM_SCRIPT_BYTES) throw new Error('Файл должен быть от 1 байта до 2 МБ.');
    const source = fs.readFileSync(sourcePath, 'utf8');
    const metadata = parseUserScript(source, path.basename(sourcePath));
    const sha256 = crypto.createHash('sha256').update(source, 'utf8').digest('hex');
    if (customScripts.some(script => script.id !== item.id && script.sha256 === sha256)) throw new Error('Такая версия уже установлена под другим именем.');
    const approved = await confirmScriptTrust(metadata.name, `Новая версия файла: ${path.basename(sourcePath)}\nТекущая запись: ${item.name}\nОписание: ${metadata.description || 'не указано'}\nСовпадение URL: ${metadata.matchPatterns.length ? metadata.matchPatterns.join(', ') : 'все страницы YouAndMe'}`);
    if (!approved) return { canceled: true, scripts: getCustomScriptsPublic() };
    const targetScriptPath = customScriptFilePath(item.id);
    const temporaryScriptPath = `${targetScriptPath}.tmp`;
    fs.writeFileSync(temporaryScriptPath, source, 'utf8');
    fs.renameSync(temporaryScriptPath, targetScriptPath);
    item.name = metadata.name;
    item.description = metadata.description;
    item.originalName = path.basename(sourcePath).slice(0, 180);
    item.matchPatterns = metadata.matchPatterns;
    item.excludePatterns = metadata.excludePatterns;
    item.grants = metadata.grants;
    item.warnings = metadata.warnings;
    item.sha256 = sha256;
    saveCustomScriptsManifest();
    logDiagnostic('Custom script updated', { id: item.id, name: item.name, sha256 });
    return { canceled: false, scripts: getCustomScriptsPublic() };
  });
  ipcMain.handle('set-custom-script-settings', async (_event, id, data) => {
    const item = customScripts.find(script => script.id === String(id));
    if (!item) throw new Error('Скрипт не найден.');
    const enabled = data?.enabled === true;
    const accounts = Array.isArray(data?.accounts)
      ? [...new Set(data.accounts.map(Number).filter(accountId => ACCOUNT_IDS.includes(accountId)))]
      : item.accounts;
    if (enabled && accounts.length === 0) throw new Error('Выбери хотя бы один аккаунт для включённого скрипта.');
    item.enabled = enabled;
    item.accounts = accounts;
    saveCustomScriptsManifest();
    for (const accountId of accounts) {
      await injectCustomScriptsForAccount(accountId, item.id);
    }
    logDiagnostic('Custom script settings changed', { id: item.id, enabled, accounts });
    return getCustomScriptsPublic();
  });
  ipcMain.handle('delete-custom-script', async (_event, id) => {
    const index = customScripts.findIndex(script => script.id === String(id));
    if (index < 0) throw new Error('Скрипт не найден.');
    const [removed] = customScripts.splice(index, 1);
    try { fs.rmSync(customScriptFilePath(removed.id), { force: true }); } catch {}
    saveCustomScriptsManifest();
    logDiagnostic('Custom script deleted', { id: removed.id, name: removed.name });
    return getCustomScriptsPublic();
  });
  ipcMain.handle('export-custom-scripts', async () => {
    const result = await dialog.showSaveDialog(getScriptManagerDialogParent(), {
      title: 'Экспорт резервной копии скриптов',
      defaultPath: 'ChatVdvoem-Scripts-Backup.json',
      filters: [{ name: 'ЧатВдвоем++ — резервная копия скриптов', extensions: ['json'] }]
    });
    if (result.canceled || !result.filePath) return { canceled: true };
    const bundle = {
      format: 'chvd-multichat-scripts-backup',
      version: 1,
      exportedAt: new Date().toISOString(),
      scripts: customScripts.map(item => ({
        name: item.name,
        description: item.description,
        originalName: item.originalName,
        enabled: item.enabled,
        accounts: item.accounts,
        sourceBase64: fs.readFileSync(customScriptFilePath(item.id)).toString('base64')
      }))
    };
    fs.writeFileSync(result.filePath, JSON.stringify(bundle, null, 2), 'utf8');
    logDiagnostic('Custom scripts backup exported', { path: result.filePath, count: bundle.scripts.length });
    return { canceled: false, count: bundle.scripts.length, path: result.filePath };
  });
  ipcMain.handle('import-custom-scripts-backup', async () => {
    const result = await dialog.showOpenDialog(getScriptManagerDialogParent(), {
      title: 'Восстановить резервную копию скриптов',
      properties: ['openFile'],
      filters: [{ name: 'ЧатВдвоем++ — резервная копия скриптов', extensions: ['json'] }]
    });
    if (result.canceled || !result.filePaths?.[0]) return { canceled: true, scripts: getCustomScriptsPublic() };
    const filePath = result.filePaths[0];
    const stat = fs.statSync(filePath);
    if (stat.size < 1 || stat.size > 12 * 1024 * 1024) throw new Error('Резервная копия должна быть не больше 12 МБ.');
    const bundle = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    if (bundle?.format !== 'chvd-multichat-scripts-backup' || bundle?.version !== 1 || !Array.isArray(bundle.scripts)) {
      throw new Error('Файл не является резервной копией ЧатВдвоем++.');
    }
    if (bundle.scripts.length > 100) throw new Error('В резервной копии слишком много скриптов (максимум 100).');
    const decoded = bundle.scripts.map((entry, index) => {
      const source = Buffer.from(String(entry.sourceBase64 || ''), 'base64').toString('utf8');
      if (!source || Buffer.byteLength(source, 'utf8') > MAX_CUSTOM_SCRIPT_BYTES) throw new Error(`Некорректный или слишком большой скрипт №${index + 1}.`);
      const metadata = parseUserScript(source, String(entry.originalName || `script-${index + 1}.js`));
      return { entry, source, metadata };
    });
    const names = decoded.slice(0, 12).map(item => `• ${item.metadata.name}`).join('\n');
    const approved = await confirmScriptTrust(`резервную копию (${decoded.length} скриптов)`, `Будут импортированы скрипты:\n${names}${decoded.length > 12 ? '\n…' : ''}`);
    if (!approved) return { canceled: true, scripts: getCustomScriptsPublic() };
    let added = 0;
    let skipped = 0;
    for (const item of decoded) {
      const hash = crypto.createHash('sha256').update(item.source, 'utf8').digest('hex');
      if (customScripts.some(script => script.sha256 === hash)) { skipped++; continue; }
      const record = addCustomScriptRecord(item.source, item.entry.originalName || `${item.metadata.name}.js`, {
        name: item.entry.name || item.metadata.name,
        description: item.entry.description || item.metadata.description,
        enabled: item.entry.enabled !== false,
        accounts: item.entry.accounts
      });
      added++;
      if (record.enabled) {
        for (const accountId of record.accounts) await injectCustomScriptsForAccount(accountId, record.id);
      }
    }
    logDiagnostic('Custom scripts backup imported', { path: filePath, added, skipped });
    return { canceled: false, added, skipped, scripts: getCustomScriptsPublic() };
  });
  ipcMain.handle('open-custom-scripts-folder', async () => {
    fs.mkdirSync(customScriptsDir, { recursive: true });
    const error = await shell.openPath(customScriptsDir);
    if (error) throw new Error(error);
    return true;
  });
  ipcMain.handle('reload-open-accounts', async () => {
    let count = 0;
    for (const view of accountViews.values()) {
      if (!view.webContents.isDestroyed()) { view.webContents.reload(); count++; }
    }
    return count;
  });
}

function startStatusPolling() {
  statusTimer = setInterval(async () => {
    if (pollingStatuses || !mainWindow || mainWindow.isDestroyed()) return;
    pollingStatuses = true;
    try {
      for (const [id, view] of accountViews.entries()) {
        if (view.webContents.isDestroyed()) continue;
        try {
          const snapshot = await view.webContents.executeJavaScript(`(() => {
            const c = window.chat;
            const guid = typeof c?.user?.guid === 'string' ? c.user.guid : '';
            let logged = false;
            try { logged = !!guid && (typeof c.isUserLoggedIn !== 'function' || c.isUserLoggedIn() !== false); } catch {}
            return { logged, guidTail: logged ? guid.slice(-4) : '', ready: !!c };
          })()`, false);
          emitStatus(id, {
            state: snapshot.logged ? 'authorized' : (snapshot.ready ? 'loaded' : 'loading'),
            guidTail: snapshot.guidTail || ''
          });
        } catch {
          // The page may be navigating or temporarily unavailable; keep last status.
        }
      }
    } finally {
      pollingStatuses = false;
    }
  }, 2500);
}

if (process.platform === 'win32') app.setAppUserModelId('chat.chvd.multichat.desktop');
// Chat media controls may play incoming audio after the original user gesture.
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

app.whenReady().then(() => {
  loadSettings();
  loadCustomScripts();
  logDiagnostic('Application started', { electron: process.versions.electron, chromium: process.versions.chrome });
  registerIpc();
  createMainWindow();
  startStatusPolling();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
}).catch((error) => {
  dialog.showErrorBox('ЧатВдвоем++', error.stack || error.message || String(error));
  app.quit();
});

app.on('before-quit', () => {
  if (statusTimer) clearInterval(statusTimer);
  if (saveTimer) clearTimeout(saveTimer);
  saveSettings();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
