'use strict';

const { contextBridge, ipcRenderer } = require('electron');

function invoke(channel, ...args) {
  return ipcRenderer.invoke(channel, ...args);
}

contextBridge.exposeInMainWorld('scriptManager', Object.freeze({
  getScripts: () => invoke('get-custom-scripts'),
  importScript: () => invoke('import-custom-script'),
  updateScript: (id) => invoke('update-custom-script', id),
  setScriptSettings: (id, data) => invoke('set-custom-script-settings', id, data),
  deleteScript: (id) => invoke('delete-custom-script', id),
  exportBackup: () => invoke('export-custom-scripts'),
  importBackup: () => invoke('import-custom-scripts-backup'),
  openScriptsFolder: () => invoke('open-custom-scripts-folder'),
  reloadOpenAccounts: () => invoke('reload-open-accounts'),
  close: () => invoke('close-script-manager')
}));
