'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = relative => fs.readFileSync(path.join(root, relative), 'utf8');
const pkg = JSON.parse(read('package.json'));
assert.equal(pkg.name, 'chvd-multichat-desktop');
assert.equal(pkg.version, '0.1.8');
assert.equal(pkg.build.productName, 'ChatVdvoem++');
assert.equal(pkg.build.nsis.shortcutName, 'ЧатВдвоем++');
assert.equal(pkg.devDependencies.electron, '45.3.1');
for (const file of [
  'main.js', 'preload.js', 'script-manager-preload.js', 'renderer/index.html', 'renderer/style.css', 'renderer/brand-icon.png', 'renderer/app-icon.ico', 'renderer/script-manager.html', 'renderer/script-manager.css', 'renderer/script-manager.js', 'build/icon.ico',
  'renderer/app.js', 'scripts/start.js', 'scripts/build.js',
  'scripts/custom-script-utils.js', 'scripts/npm-runner.js', 'examples/hello-multichat.user.js', 'RUN.bat', 'BUILD_EXE.bat', 'CHECK_ENV.bat', 'DEBUG_INSTALLER.bat', 'CHECK_INSTALLED.bat', 'RUN_UNPACKED_APP.bat'
]) assert.ok(fs.existsSync(path.join(root, file)), `Missing file: ${file}`);
const main = read('main.js');
const preload = read('preload.js');
const renderer = read('renderer/app.js');
const html = read('renderer/index.html');
const managerHtml = read('renderer/script-manager.html');
const managerJs = read('renderer/script-manager.js');
const managerPreload = read('script-manager-preload.js');
const utils = require('./custom-script-utils');
const npmRunner = require('./npm-runner');
assert.ok(npmRunner.findNpmRunner(), 'npm resolver must locate npm in the build environment');
assert.match(main, /new WebContentsView\(/);
assert.match(main, /const HEADER_HEIGHT = 48;/);
assert.doesNotMatch(main, /loaderEnabled|loaderSource|loaderPath|chvd-loader|set-loader-enabled/);
assert.match(main, /const FOOTER_HEIGHT = 28;/);
assert.match(main, /const PANE_HEADER_HEIGHT = 28;/);
assert.match(main, /persist:chvd-multichat-account-\$\{accountId\}/);
assert.match(main, /safeStorage\.encryptString/);
assert.match(main, /safeStorage\.decryptString/);
assert.match(main, /permission === 'fileSystem'/);
assert.match(main, /file-system-access-restricted/);
assert.match(main, /approvedFileRoots/);
assert.match(main, /customScriptsDir/);
assert.match(main, /executeJavaScript\(wrapper, false\)/);
assert.match(main, /const unsafeWindow = window/);
assert.match(main, /get-custom-scripts/);
assert.match(main, /nodeIntegration:\s*false/);
assert.match(main, /contextIsolation:\s*true/);
assert.match(main, /sandbox:\s*true/);
assert.match(preload, /contextBridge\.exposeInMainWorld/);
assert.match(preload, /openScriptManager/);
assert.doesNotMatch(preload, /setLoaderEnabled/);
for (const api of ['getScripts', 'importScript', 'setScriptSettings', 'deleteScript', 'exportBackup', 'importBackup', 'updateScript', 'openScriptsFolder', 'reloadOpenAccounts', 'close']) {
  assert.match(managerPreload, new RegExp(api));
}
assert.match(renderer, /openScriptManager\(\)/);
assert.match(renderer, /openScriptsButton/);
assert.doesNotMatch(html, /scriptManagerDialog/);
assert.match(main, /new BrowserWindow\([\s\S]*?preload: path\.join\(__dirname, 'script-manager-preload\.js'\)/);
assert.match(main, /renderer', 'script-manager\.html/);
assert.match(managerHtml, /id="importButton"/);
assert.match(managerJs, /api\.importScript\(\)/);
assert.match(managerPreload, /contextBridge\.exposeInMainWorld\('scriptManager'/);
assert.equal(pkg.build.nsis.allowElevation, false);
assert.equal(pkg.build.nsis.perMachine, false);
assert.match(html, /id="openScriptsButton"/);
assert.match(html, /ЧатВдвоем\+\+/);
assert.match(html, /brand-icon\.png/);
assert.match(html, /Добро пожаловать!/);
assert.doesNotMatch(html, /MultiChat|CHVD|Журнал|облачные модули|Сессии аккаунтов независимы|Три независимых чата/);
assert.doesNotMatch(renderer, /loaderToggle|setLoaderEnabled|openDiagnosticsButton|sessionStatus/);
assert.match(managerHtml, /id="importButton"/);
assert.match(managerHtml, /id="exportButton"/);
assert.match(managerHtml, /brand-icon\.png/);
assert.doesNotMatch(managerHtml, /MULTICHAT DESKTOP|CHVD\+\+/);
assert.ok(pkg.build.files.includes('scripts/custom-script-utils.js'), 'Custom script utility must be packaged with the app');
assert.ok(pkg.build.files.includes('script-manager-preload.js'), 'Dedicated script manager preload must be packaged');
assert.equal(pkg.build.nsis.createDesktopShortcut, true);
assert.equal(pkg.build.nsis.createStartMenuShortcut, true);
assert.equal(pkg.build.nsis.deleteAppDataOnUninstall, false);
assert.equal(pkg.build.win.icon, 'build/icon.ico');
assert.match(main, /path\.join\(__dirname, 'renderer', 'app-icon\.ico'\)/);
assert.equal(pkg.build.win.signAndEditExecutable, true, 'App executable must be edited so the custom icon is embedded');
assert.equal(fs.existsSync(path.join(root, 'resources', 'chvd-loader.js')), false, 'Cloud bootstrap loader must be removed');
assert.ok(!pkg.build.files.some(entry => entry.startsWith('resources/')), 'Cloud loader folder must not be packaged');

const userscript = `// ==UserScript==\n// @name        Smoke Test\n// @description Test script\n// @match       https://youandme.chat/*\n// @grant       none\n// ==/UserScript==\nconsole.log('ok');`;
const metadata = utils.parseUserScript(userscript, 'smoke.user.js');
assert.equal(metadata.name, 'Smoke Test');
assert.equal(metadata.matchPatterns.length, 1);
assert.equal(utils.scriptMatchesUrl(metadata, 'https://youandme.chat/'), true);
assert.equal(utils.scriptMatchesUrl(metadata, 'https://www.youandme.chat/chat'), false);
const excluding = utils.parseUserScript('// ==UserScript==\n// @match https://youandme.chat/*\n// @exclude https://youandme.chat/admin/*\n// ==/UserScript==\nconsole.log(1);', 'exclude.js');
assert.equal(utils.scriptMatchesUrl(excluding, 'https://youandme.chat/chat'), true);
assert.equal(utils.scriptMatchesUrl(excluding, 'https://youandme.chat/admin/users'), false);
assert.equal(utils.scriptMatchesUrl({ matchPatterns: [] }, 'https://www.youandme.chat/'), true);
assert.equal(utils.scriptMatchesUrl({ matchPatterns: [] }, 'https://example.com/'), false);
assert.throws(() => utils.parseUserScript('// ==UserScript==\n// @match https://example.com/*\n// ==/UserScript==\n', 'bad.js'), /Небезопасный/);
assert.throws(() => utils.parseUserScript('// ==UserScript==\n// @require https://example.com/lib.js\n// ==/UserScript==\n', 'external.js'), /@require/);
console.log('Smoke check passed: Electron isolation, persistent sessions, local script manager, compact UI, branding, installer config and URL scoping.');

for (const batchName of ['RUN.bat', 'BUILD_EXE.bat', 'CHECK_ENV.bat', 'DEBUG_INSTALLER.bat', 'CHECK_INSTALLED.bat', 'RUN_UNPACKED_APP.bat']) {
  const bytes = fs.readFileSync(path.join(root, batchName));
  assert.ok(bytes.length > 0, `${batchName} is empty`);
  assert.equal((bytes.toString('ascii').match(/\r\n/g) || []).length, (bytes.toString('ascii').match(/\n/g) || []).length, `${batchName} must use Windows CRLF line endings`);
  assert.ok(bytes.every(byte => byte < 128), `${batchName} must contain ASCII only`);
}
