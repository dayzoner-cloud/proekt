'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

function unique(values) {
  return [...new Set(values.filter(Boolean).map(value => path.resolve(value)))];
}

function findNpmRunner(options = {}) {
  const platform = options.platform || process.platform;
  const execPath = options.execPath || process.execPath;
  const env = options.env || process.env;
  const exists = options.exists || fs.existsSync;
  const spawn = options.spawnSync || spawnSync;
  const nodeDir = path.dirname(execPath);
  const pathDirs = String(env.PATH || env.Path || '').split(path.delimiter).filter(Boolean);
  const searchDirs = unique([nodeDir, ...pathDirs]);

  const cliCandidates = unique([
    env.npm_execpath,
    ...searchDirs.flatMap(dir => [
      path.join(dir, 'node_modules', 'npm', 'bin', 'npm-cli.js'),
      path.join(dir, '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js'),
      path.join(dir, '..', 'node_modules', 'npm', 'bin', 'npm-cli.js')
    ])
  ]);

  for (const cli of cliCandidates) {
    if (exists(cli)) return { kind: 'node-cli', cli };
  }

  if (platform === 'win32') {
    const cmdCandidates = unique(searchDirs.map(dir => path.join(dir, 'npm.cmd')));
    for (const cmd of cmdCandidates) {
      if (exists(cmd)) return { kind: 'windows-cmd', cmd };
    }

    // `where.exe` also handles npm.cmd entries exposed through Windows PATH semantics.
    const where = spawn('where.exe', ['npm.cmd'], {
      encoding: 'utf8',
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'ignore']
    });
    if (!where.error && where.status === 0) {
      const found = String(where.stdout || '').split(/\r?\n/).map(line => line.trim()).find(Boolean);
      if (found && exists(found)) return { kind: 'windows-cmd', cmd: found };
    }
  }

  return null;
}

function runNpm(args, options = {}) {
  const root = options.cwd || process.cwd();
  const runner = findNpmRunner(options);
  if (!runner) {
    const error = new Error(
      'Не удалось найти npm. Node.js обнаружен, но npm.cmd/npm-cli.js не найден. ' +
      'Переустанови или измени установку Node.js с компонентом npm, затем полностью закрой и заново открой CMD. ' +
      'Проверка в CMD: where node и where npm.'
    );
    error.code = 'CHVD_NPM_NOT_FOUND';
    throw error;
  }

  const common = {
    cwd: root,
    stdio: 'inherit',
    windowsHide: false,
    env: options.env || process.env
  };

  if (runner.kind === 'node-cli') {
    return spawnSync(process.execPath, [runner.cli, ...args], common);
  }

  // The .cmd shim must be launched through cmd.exe on Windows.
  const quote = value => `"${String(value).replace(/"/g, '""')}"`;
  const command = `${quote(runner.cmd)} ${args.map(quote).join(' ')}`;
  return spawnSync(command, [], { ...common, shell: true });
}

module.exports = { findNpmRunner, runNpm };
