'use strict';

const path = require('node:path');

const TRUSTED_HOSTS = new Set(['youandme.chat', 'www.youandme.chat']);
const MAX_CUSTOM_SCRIPT_BYTES = 2 * 1024 * 1024;

function parseUserScript(source, originalName) {
  if (typeof source !== 'string' || !source.trim()) throw new Error('Файл скрипта пустой.');
  if (Buffer.byteLength(source, 'utf8') > MAX_CUSTOM_SCRIPT_BYTES) throw new Error('Размер скрипта превышает 2 МБ.');
  if (source.includes('\u0000')) throw new Error('Файл содержит недопустимые нулевые байты.');

  const header = source.match(/^\s*\/\/\s*==UserScript==([\s\S]*?)^\s*\/\/\s*==\/UserScript==/mi)?.[1] || '';
  const tags = [...header.matchAll(/^\s*\/\/\s*@([\w:-]+)\s+(.+?)\s*$/gm)];
  const values = key => tags.filter(match => match[1].toLowerCase() === key.toLowerCase()).map(match => match[2].trim());
  const originalBaseName = path.basename(originalName || 'custom-script.js');
  const name = (values('name')[0] || values('name:ru')[0] || originalBaseName).slice(0, 100);
  const description = (values('description:ru')[0] || values('description')[0] || '').slice(0, 240);
  const matchPatterns = [...values('match'), ...values('include')].slice(0, 20);
  const excludePatterns = values('exclude').slice(0, 20);
  const grants = values('grant').slice(0, 30);
  const requires = [...values('require'), ...values('resource')];
  if (requires.length) {
    throw new Error('Этот скрипт использует @require или @resource. Внешние зависимости пока не загружаются. Объедини нужный код в один JS-файл и импортируй повторно.');
  }
  for (const pattern of [...matchPatterns, ...excludePatterns]) {
    if (!isSupportedScriptMatchPattern(pattern)) {
      throw new Error(`Небезопасный или неподдерживаемый @match/@include/@exclude: ${pattern}. Разрешены только адреса YouAndMe (youandme.chat и www.youandme.chat).`);
    }
  }

  const warnings = [];
  const unsupportedGrants = grants.filter(grant => !['none', 'unsafeWindow'].includes(grant));
  if (unsupportedGrants.length) warnings.push(`GM API не реализованы: ${unsupportedGrants.join(', ')}`);
  if (values('run-at').some(value => !['document-idle', 'document-end'].includes(value.toLowerCase()))) {
    warnings.push('Время @run-at будет приведено к document-idle. document-start не поддерживается.');
  }
  if (values('connect').length) warnings.push('@connect не управляется Tampermonkey; сетевые запросы выполняются по обычным правилам страницы.');

  return { name, description, matchPatterns, excludePatterns, grants, warnings };
}

function isSupportedScriptMatchPattern(pattern) {
  const value = String(pattern || '').trim();
  const normalized = value.replace(/^\*:\/\//, 'https://');
  const match = normalized.match(/^https:\/\/([^/]+)(\/.*)$/i);
  if (!match) return false;
  const host = match[1].toLowerCase();
  if (!['youandme.chat', 'www.youandme.chat', '*.youandme.chat'].includes(host)) return false;
  return match[2].startsWith('/');
}

function scriptMatchesUrl(script, rawUrl) {
  let url;
  try { url = new URL(rawUrl); } catch { return false; }
  if (url.protocol !== 'https:' || !TRUSTED_HOSTS.has(url.hostname)) return false;
  const matchesPattern = pattern => {
    const normalized = String(pattern).replace(/^\*:\/\//, 'https://');
    const match = normalized.match(/^https:\/\/([^/]+)(\/.*)$/i);
    if (!match) return false;
    const hostPattern = match[1].toLowerCase();
    const hostMatches = hostPattern === '*.youandme.chat'
      ? (url.hostname === 'youandme.chat' || url.hostname.endsWith('.youandme.chat'))
      : url.hostname === hostPattern;
    if (!hostMatches) return false;
    const pathPattern = match[2];
    const escaped = pathPattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
    try { return new RegExp(`^${escaped}$`).test(url.pathname + url.search + url.hash); } catch { return false; }
  };
  const matches = !Array.isArray(script.matchPatterns) || script.matchPatterns.length === 0 || script.matchPatterns.some(matchesPattern);
  const excluded = Array.isArray(script.excludePatterns) && script.excludePatterns.some(matchesPattern);
  return matches && !excluded;
}

module.exports = { parseUserScript, scriptMatchesUrl, isSupportedScriptMatchPattern };
