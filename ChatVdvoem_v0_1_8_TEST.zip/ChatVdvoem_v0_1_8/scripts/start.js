'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { runNpm } = require('./npm-runner');

const root = path.resolve(__dirname, '..');

function run(command, args, options = {}) {
  const result = spawnSync(command, args, {
    cwd: root,
    stdio: 'inherit',
    windowsHide: false,
    shell: false,
    ...options
  });
  if (result.error) throw result.error;
  if (result.signal) throw new Error(`${command} stopped by signal ${result.signal}`);
  return result.status ?? 1;
}

function majorVersion(version) {
  const match = String(version).match(/^(\d+)\./);
  return match ? Number(match[1]) : 0;
}

try {
  const nodeMajor = majorVersion(process.versions.node);
  if (nodeMajor < 20) {
    throw new Error(`Node.js 20 or newer is required. Current version: ${process.versions.node}`);
  }

  const electronCli = path.join(root, 'node_modules', 'electron', 'cli.js');
  if (!fs.existsSync(electronCli)) {
    console.log('First launch: installing Electron dependencies. Internet access is required.');
    const installResult = runNpm(['install', '--no-audit', '--no-fund'], { cwd: root });
    if (installResult.error) throw installResult.error;
    if (installResult.signal) throw new Error(`npm install stopped by signal ${installResult.signal}`);
    if (installResult.status !== 0) throw new Error(`npm install failed with exit code ${installResult.status ?? 1}`);
  }

  if (!fs.existsSync(electronCli)) {
    throw new Error('Electron was not installed. Delete node_modules and run RUN.bat again.');
  }

  console.log('Starting ChatVdvoem++...');
  const appCode = run(process.execPath, [electronCli, '.']);
  if (appCode !== 0) process.exitCode = appCode;
} catch (error) {
  console.error('\nSTARTUP ERROR:');
  console.error(error && error.stack ? error.stack : String(error));
  process.exitCode = 1;
}
