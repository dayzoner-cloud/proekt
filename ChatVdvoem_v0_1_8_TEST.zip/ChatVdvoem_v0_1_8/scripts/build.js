'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { runNpm } = require('./npm-runner');

const root = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

function run(command, args) {
  const result = spawnSync(command, args, {
    cwd: root,
    stdio: 'inherit',
    windowsHide: false,
    shell: false
  });
  if (result.error) throw result.error;
  if (result.signal) throw new Error(`${command} stopped by signal ${result.signal}`);
  return result.status ?? 1;
}

function printEnvironment() {
  console.log(`Node.js: ${process.version}`);
  console.log(`Node executable: ${process.execPath}`);
  try {
    const { findNpmRunner } = require('./npm-runner');
    const npm = findNpmRunner();
    console.log(`npm: ${npm ? (npm.kind === 'node-cli' ? npm.cli : npm.cmd) : 'NOT FOUND'}`);
  } catch (error) {
    console.log(`npm: unavailable (${error.message})`);
  }
}

try {
  const nodeMajor = Number(process.versions.node.split('.')[0]);
  if (!Number.isFinite(nodeMajor) || nodeMajor < 20) {
    throw new Error(`Node.js 20 or newer is required. Current version: ${process.versions.node}`);
  }

  if (process.argv.includes('--diagnose')) {
    printEnvironment();
    process.exit(0);
  }

  printEnvironment();
  const electronCli = path.join(root, 'node_modules', 'electron', 'cli.js');
  const builderCli = path.join(root, 'node_modules', 'electron-builder', 'out', 'cli', 'cli.js');
  if (!fs.existsSync(electronCli) || !fs.existsSync(builderCli)) {
    console.log('\nInstalling Electron and Windows packaging dependencies...');
    const install = runNpm(['install', '--no-audit', '--no-fund'], { cwd: root });
    if (install.error) throw install.error;
    if (install.signal) throw new Error(`npm install stopped by signal ${install.signal}`);
    if (install.status !== 0) throw new Error(`npm install failed with exit code ${install.status ?? 1}`);
  }

  if (!fs.existsSync(electronCli) || !fs.existsSync(builderCli)) {
    throw new Error('Dependencies are still missing after npm install. Check the npm output above.');
  }

  console.log('\nBuilding Windows x64 NSIS installer...');
  const code = run(process.execPath, [builderCli, '--win', 'nsis', '--x64']);
  if (code !== 0) throw new Error(`electron-builder failed with exit code ${code}`);

  const installer = path.join(root, 'dist', `ChatVdvoem_Setup_${pkg.version}.exe`);
  if (!fs.existsSync(installer)) {
    throw new Error(`Build process returned success, but the installer was not found: ${installer}`);
  }
  const size = fs.statSync(installer).size;
  if (size < 100 * 1024) {
    throw new Error(`Installer file is unexpectedly small (${size} bytes): ${installer}`);
  }

  console.log('\nBUILD SUCCESS');
  console.log(`Installer: ${installer}`);
  console.log(`Size: ${(size / (1024 * 1024)).toFixed(1)} MB`);
  if (process.platform === 'win32') {
    spawnSync('explorer.exe', [path.dirname(installer)], { stdio: 'ignore', windowsHide: true });
  }
} catch (error) {
  console.error('\nBUILD ERROR:');
  console.error(error && error.stack ? error.stack : String(error));
  console.error('\nNo installer is considered ready unless the exact EXE exists in the dist folder.');
  process.exitCode = 1;
}
