'use strict';

const { contextBridge, ipcRenderer } = require('electron');

function invoke(channel, ...args) {
  return ipcRenderer.invoke(channel, ...args);
}

contextBridge.exposeInMainWorld('multiChat', {
  getState: () => invoke('get-state'),
  setCount: (count) => invoke('set-count', count),
  launch: () => invoke('launch'),
  closeChats: () => invoke('close-chats'),
  reloadAccount: (id) => invoke('reload-account', id),
  homeAccount: (id) => invoke('home-account', id),
  openDevTools: (id) => invoke('devtools-account', id),
  focusAccount: (id) => invoke('focus-account', id),
  saveAccountSettings: (id, data) => invoke('save-account-settings', id, data),
  saveCredentials: (id, data) => invoke('save-credentials', id, data),
  clearCredentials: (id) => invoke('clear-credentials', id),
  fillCredentials: (id) => invoke('fill-credentials', id),
  openDiagnostics: () => invoke('open-diagnostics'),
  openScriptManager: () => invoke('open-script-manager'),
  onAccountStatus: (callback) => {
    if (typeof callback !== 'function') return () => {};
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('account-status', listener);
    return () => ipcRenderer.removeListener('account-status', listener);
  },
  onPaneLayout: (callback) => {
    if (typeof callback !== 'function') return () => {};
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('pane-layout', listener);
    return () => ipcRenderer.removeListener('pane-layout', listener);
  },
  onAppState: (callback) => {
    if (typeof callback !== 'function') return () => {};
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('app-state', listener);
    return () => ipcRenderer.removeListener('app-state', listener);
  }
});
