'use strict';

const $ = (selector) => document.querySelector(selector);
const accountStates = new Map();
let currentCount = 3;
let currentModalAccount = null;
let toastTimer = null;

const countButtons = [...document.querySelectorAll('[data-count]')];
const paneHeaders = $('#paneHeaders');
const welcome = $('#welcome');
const launchButton = $('#launchButton');
const reloadAllButton = $('#reloadAllButton');
const closeChatsButton = $('#closeChatsButton');
const accountDialog = $('#accountDialog');

function showToast(message, isError = false) {
  document.querySelector('.toast')?.remove();
  const node = document.createElement('div');
  node.className = 'toast';
  node.textContent = message;
  if (isError) node.style.borderColor = 'rgba(227,110,116,.55)';
  document.body.appendChild(node);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.remove(), 4200);
}

function setBusy(button, busy, busyText = 'Подождите…') {
  if (!button) return;
  if (busy) {
    button.dataset.originalText = button.textContent;
    button.textContent = busyText;
    button.disabled = true;
  } else {
    button.textContent = button.dataset.originalText || button.textContent;
    button.disabled = false;
  }
}

function updateCountButtons() {
  countButtons.forEach(button => button.classList.toggle('selected', Number(button.dataset.count) === currentCount));
}

function updateGlobalStatus() {
  const active = [...accountStates.values()].filter(item => item.opened).length;
  const authorized = [...accountStates.values()].filter(item => item.opened && item.status?.state === 'authorized').length;
  $('#globalStatus').textContent = active ? `Открыто окон: ${active} · авторизовано: ${authorized}` : 'Готов к запуску';
  launchButton.disabled = false;
  launchButton.innerHTML = active ? '<span class="button-icon">▶</span> ПОКАЗАТЬ ЧАТЫ' : '<span class="button-icon">▶</span> ОТКРЫТЬ ЧАТЫ';
  reloadAllButton.disabled = active === 0;
  closeChatsButton.disabled = active === 0;
}

function refreshPaneHeader(id) {
  const geometry = window.__paneGeometry?.find(item => item.id === id);
  if (!geometry) return;
  const oldHeader = [...paneHeaders.children].find(el => Number(el.dataset.accountId) === id);
  const replacement = createHeaderNode(id, geometry);
  if (oldHeader) oldHeader.replaceWith(replacement);
  else paneHeaders.appendChild(replacement);
}

function mergeState(state) {
  currentCount = state.visibleCount || currentCount;
  (state.accounts || []).forEach(item => accountStates.set(item.id, item));
  updateCountButtons();
  updateGlobalStatus();
}

async function runAction(action) {
  try {
    await action();
  } catch (error) {
    showToast(error?.message || String(error), true);
  }
}

async function openAccountDialog(id) {
  currentModalAccount = id;
  const state = accountStates.get(id) || {};
  $('#modalTitle').textContent = state.label || `Аккаунт ${id}`;
  $('#accountLabel').value = state.label || `Аккаунт ${id}`;
  $('#accountUsername').value = state.username || '';
  $('#accountPassword').value = '';
  $('#accountPassword').placeholder = state.hasCredentials ? 'Сохранённый пароль (оставь пустым, чтобы не менять)' : 'Пароль YouAndMe';
  $('#autoFillToggle').checked = state.autoFill === true;
  $('#clearCredentialsButton').disabled = !state.hasCredentials;
  $('#credentialHint').textContent = state.hasCredentials
    ? 'Логин сохранён. Пароль зашифрован Windows DPAPI. Пустое поле пароля оставит прежний пароль. Форма не отправляется автоматически — CAPTCHA подтверждаешь сам.'
    : 'Логин и пароль будут зашифрованы средствами Windows DPAPI. Приложение только заполнит форму: CAPTCHA и отправку формы подтверждаешь сам.';
  accountDialog.showModal();
}

countButtons.forEach(button => button.addEventListener('click', async () => {
  const count = Number(button.dataset.count);
  try {
    const state = await window.multiChat.setCount(count);
    mergeState(state);
    showToast(`Выбрано аккаунтов: ${count}`);
  } catch (error) { showToast(error.message || String(error), true); }
}));

launchButton.addEventListener('click', async () => {
  setBusy(launchButton, true, 'Открываю…');
  try {
    const state = await window.multiChat.launch();
    mergeState(state);
    showToast(`Открываю ${currentCount} независимых аккаунта(ов). Вход и CAPTCHA — отдельно для каждого.`);
  } catch (error) { showToast(error.message || String(error), true); }
  finally { setBusy(launchButton, false); updateGlobalStatus(); }
});

reloadAllButton.addEventListener('click', async () => {
  await runAction(async () => {
    for (let id = 1; id <= currentCount; id++) await window.multiChat.reloadAccount(id);
    showToast('Все открытые аккаунты обновляются.');
  });
});

closeChatsButton.addEventListener('click', async () => {
  await runAction(async () => {
    const state = await window.multiChat.closeChats();
    mergeState(state);
    renderPaneHeaders([]);
    showToast('Окна закрыты. Авторизация и локальные данные сохранены.');
  });
});

$('#cancelDialogButton').addEventListener('click', () => accountDialog.close());

$('#accountForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!currentModalAccount) return;
  const id = currentModalAccount;
  const saveButton = $('#accountForm button[type="submit"]');
  setBusy(saveButton, true, 'Сохраняю…');
  try {
    const publicItem = await window.multiChat.saveAccountSettings(id, {
      label: $('#accountLabel').value,
      autoFill: $('#autoFillToggle').checked
    });
    const username = $('#accountUsername').value.trim();
    const password = $('#accountPassword').value;
    if (username) {
      const credentialState = await window.multiChat.saveCredentials(id, { username, password });
      Object.assign(publicItem, credentialState);
    }
    accountStates.set(id, publicItem);
    refreshPaneHeader(id);
    accountDialog.close();
    showToast(`Настройки аккаунта ${id} сохранены.`);
  } catch (error) {
    showToast(error?.message || String(error), true);
  } finally {
    setBusy(saveButton, false);
  }
});

$('#fillCredentialsButton').addEventListener('click', async () => {
  if (!currentModalAccount) return;
  const id = currentModalAccount;
  try {
    const label = $('#accountLabel').value;
    const autoFill = $('#autoFillToggle').checked;
    await window.multiChat.saveAccountSettings(id, { label, autoFill });
    const username = $('#accountUsername').value.trim();
    const password = $('#accountPassword').value;
    if (username) {
      const item = await window.multiChat.saveCredentials(id, { username, password });
      accountStates.set(id, item);
    }
    await window.multiChat.fillCredentials(id);
    refreshPaneHeader(id);
    showToast(`Форма входа аккаунта ${id} заполнена. Проверь CAPTCHA и подтверди вход на сайте.`);
  } catch (error) {
    showToast(error?.message || String(error), true);
  }
});

$('#clearCredentialsButton').addEventListener('click', async () => {
  if (!currentModalAccount) return;
  if (!confirm('Удалить сохранённые логин и пароль этого аккаунта?')) return;
  try {
    const publicItem = await window.multiChat.clearCredentials(currentModalAccount);
    accountStates.set(currentModalAccount, publicItem);
    $('#accountUsername').value = '';
    $('#accountPassword').value = '';
    $('#accountPassword').placeholder = 'Пароль YouAndMe';
    $('#clearCredentialsButton').disabled = true;
    showToast('Сохранённые данные удалены.');
  } catch (error) { showToast(error?.message || String(error), true); }
});

window.multiChat.onAccountStatus((status) => {
  const old = accountStates.get(status.id) || { id: status.id, label: `Аккаунт ${status.id}` };
  accountStates.set(status.id, { ...old, status, opened: status.state !== 'inactive' });
  updateGlobalStatus();
  // Main sends fresh pane layout after creation; redraw headers to refresh status.
  refreshPaneHeader(status.id);
});

function createHeaderNode(id, geometry) {
  const state = accountStates.get(id) || { id, label: `Аккаунт ${id}` };
  const status = state.status || {};
  const header = document.createElement('div');
  header.className = 'pane-header';
  header.dataset.accountId = String(id);
  header.style.cssText = `left:${geometry.x}px;top:${geometry.y}px;width:${geometry.width}px;height:${geometry.headerHeight}px`;
  const dot = document.createElement('span');
  dot.className = `pane-dot ${status.state === 'authorized' ? 'online' : status.state === 'loading' ? 'loading' : ''}`;
  header.appendChild(dot);
  const name = document.createElement('span'); name.className = 'pane-name'; name.textContent = state.label || `Аккаунт ${id}`; header.appendChild(name);
  const stateText = document.createElement('span'); stateText.className = 'pane-state';
  stateText.textContent = status.state === 'authorized' ? 'АВТОРИЗОВАН' : status.state === 'loading' ? 'ЗАГРУЗКА' : status.state === 'error' ? 'ОШИБКА' : status.state === 'loaded' ? 'ОТКРЫТ' : 'ГОТОВ'; header.appendChild(stateText);
  if (status.guidTail) { const guid = document.createElement('span'); guid.className = 'pane-guid'; guid.textContent = `…${status.guidTail}`; header.appendChild(guid); }
  const tools = document.createElement('div'); tools.className = 'pane-tools';
  const add = (symbol, title, fn) => { const b = document.createElement('button'); b.className = 'pane-tool'; b.type = 'button'; b.title = title; b.textContent = symbol; b.addEventListener('click', fn); tools.appendChild(b); };
  add('🔑','Данные для входа',()=>openAccountDialog(id));
  add('↻','Обновить аккаунт',()=>runAction(()=>window.multiChat.reloadAccount(id)));
  add('⌂','На главную',()=>runAction(()=>window.multiChat.homeAccount(id)));
  add('⚙','Инструменты разработчика',()=>runAction(()=>window.multiChat.openDevTools(id)));
  header.appendChild(tools);
  return header;
}

window.multiChat.onPaneLayout((layout) => {
  window.__paneGeometry = Array.isArray(layout) ? layout : [];
  paneHeaders.replaceChildren();
  if (!layout?.length) {
    welcome.hidden = false;
    return;
  }
  welcome.hidden = true;
  layout.forEach(item => {
    const state = accountStates.get(item.id) || { id: item.id, label: `Аккаунт ${item.id}` };
    accountStates.set(item.id, { ...state, opened: true });
    paneHeaders.appendChild(createHeaderNode(item.id, item));
  });
  updateGlobalStatus();
});

window.multiChat.onAppState(mergeState);

(async function init() {
  try {
    const state = await window.multiChat.getState();
    mergeState(state);
  } catch (error) {
    showToast(error?.message || String(error), true);
  }
})();

// The script manager is a separate native BrowserWindow. WebContentsView chat panes
// sit above the main window's renderer, so an HTML <dialog> here would be obscured.
const openScriptsButton = $('#openScriptsButton');
openScriptsButton?.addEventListener('click', async () => {
  try {
    await window.multiChat.openScriptManager();
  } catch (error) {
    showToast(error?.message || String(error), true);
  }
});
