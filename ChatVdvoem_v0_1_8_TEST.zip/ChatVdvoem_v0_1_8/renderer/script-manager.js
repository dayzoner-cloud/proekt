'use strict';

const $ = selector => document.querySelector(selector);
const api = window.scriptManager;
let toastTimer = null;

function toast(message, isError = false) {
  const node = $('#toast');
  node.textContent = String(message || '');
  node.classList.toggle('error', isError);
  node.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { node.hidden = true; }, 4500);
}

function make(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function action(button, busyText, callback) {
  return async () => {
    const oldText = button.textContent;
    button.disabled = true;
    button.textContent = busyText;
    try { await callback(); }
    catch (error) { toast(error?.message || String(error), true); }
    finally { button.disabled = false; button.textContent = oldText; }
  };
}

function renderScripts(items) {
  const list = $('#scriptList');
  list.replaceChildren();
  const scripts = Array.isArray(items) ? items : [];
  $('#scriptCount').textContent = `Всего: ${scripts.length} · хранятся отдельно от программы`;
  if (!scripts.length) {
    list.appendChild(make('div', 'empty', 'Пока нет пользовательских скриптов. Нажми «Добавить JS», выбери файл .js или .user.js и подтверди установку.'));
    return;
  }

  for (const item of scripts) {
    const card = make('article', 'script-item');
    const head = make('div', 'script-head');
    const info = make('div', 'script-info');
    info.appendChild(make('div', 'script-name', item.name || item.originalName || 'Без названия'));
    if (item.description) info.appendChild(make('div', 'script-desc', item.description));
    info.appendChild(make('div', 'script-file', item.originalName || 'custom.js'));

    const actions = make('div', 'script-actions');
    const update = make('button', '', 'Обновить');
    update.type = 'button';
    update.addEventListener('click', action(update, 'Выбор…', async () => {
      const result = await api.updateScript(item.id);
      if (!result.canceled) { renderScripts(result.scripts); toast('Новая версия сохранена. Перезагрузи нужные чаты.'); }
    }));
    const remove = make('button', 'danger', 'Удалить');
    remove.type = 'button';
    remove.addEventListener('click', action(remove, 'Удаление…', async () => {
      const approved = window.confirm(`Удалить скрипт «${item.name}» из библиотеки?`);
      if (!approved) return;
      const result = await api.deleteScript(item.id);
      renderScripts(result);
      toast('Скрипт удалён из библиотеки. Уже работающий код остановится после перезагрузки чата.');
    }));
    actions.append(update, remove);

    const enabledLabel = make('label', 'enable');
    const enabled = document.createElement('input');
    enabled.type = 'checkbox';
    enabled.checked = item.enabled === true;
    enabledLabel.append(enabled, make('span', '', 'Включён'));
    head.append(info, actions);
    card.append(head, enabledLabel);

    const accounts = make('div', 'accounts');
    accounts.appendChild(make('span', 'accounts-title', 'ЗАПУСКАТЬ В:'));
    const accountInputs = [];
    for (let id = 1; id <= 4; id++) {
      const label = make('label', 'account-check');
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.checked = Array.isArray(item.accounts) && item.accounts.includes(id);
      input.dataset.account = String(id);
      label.append(input, make('span', '', `Аккаунт ${id}`));
      accounts.appendChild(label);
      accountInputs.push(input);
    }
    card.appendChild(accounts);

    if (item.matchPatterns?.length) card.appendChild(make('div', 'meta-line', `URL: ${item.matchPatterns.join(' · ')}`));
    else card.appendChild(make('div', 'meta-line', 'URL: все страницы YouAndMe'));
    if (item.excludePatterns?.length) card.appendChild(make('div', 'meta-line', `Исключения: ${item.excludePatterns.join(' · ')}`));
    if (item.warnings?.length) card.appendChild(make('div', 'warning', `Совместимость: ${item.warnings.join(' · ')}`));
    if (item.grants?.length) card.appendChild(make('div', 'warning', `@grant: ${item.grants.join(', ')}. API GM_* не предоставляются.`));

    let saving = false;
    const persist = async () => {
      if (saving) return;
      saving = true;
      try {
        const accountIds = accountInputs.filter(input => input.checked).map(input => Number(input.dataset.account));
        const updated = await api.setScriptSettings(item.id, { enabled: enabled.checked, accounts: accountIds });
        renderScripts(updated);
        toast('Настройки сохранены. Перезагрузи открытые чаты для применения.');
      } catch (error) {
        toast(error?.message || String(error), true);
        const current = await api.getScripts().catch(() => null);
        if (current) renderScripts(current);
      } finally { saving = false; }
    };
    enabled.addEventListener('change', persist);
    accountInputs.forEach(input => input.addEventListener('change', persist));
    list.appendChild(card);
  }
}

async function refresh() {
  try { renderScripts(await api.getScripts()); }
  catch (error) { toast(error?.message || String(error), true); }
}

$('#closeButton').addEventListener('click', () => api.close());
$('#doneButton').addEventListener('click', () => api.close());
$('#refreshButton').addEventListener('click', action($('#refreshButton'), 'Обновление…', refresh));
$('#importButton').addEventListener('click', action($('#importButton'), 'Выбор файла…', async () => {
  const result = await api.importScript();
  if (!result.canceled) { renderScripts(result.scripts); toast('Скрипт добавлен. Отметь нужные аккаунты и перезагрузи чаты.'); }
}));
$('#restoreButton').addEventListener('click', action($('#restoreButton'), 'Импорт…', async () => {
  const result = await api.importBackup();
  if (!result.canceled) { renderScripts(result.scripts); toast(`Backup обработан: добавлено ${result.added}, пропущено ${result.skipped}.`); }
}));
$('#exportButton').addEventListener('click', action($('#exportButton'), 'Экспорт…', async () => {
  const result = await api.exportBackup();
  if (!result.canceled) toast(`Резервная копия сохранена. Скриптов: ${result.count}.`);
}));
$('#folderButton').addEventListener('click', action($('#folderButton'), 'Открытие…', async () => {
  await api.openScriptsFolder();
  toast('Открыта папка пользовательских скриптов.');
}));
$('#reloadChatsButton').addEventListener('click', action($('#reloadChatsButton'), 'Перезагрузка…', async () => {
  const count = await api.reloadOpenAccounts();
  toast(`Перезагружено чатов: ${count}.`);
}));

refresh();
