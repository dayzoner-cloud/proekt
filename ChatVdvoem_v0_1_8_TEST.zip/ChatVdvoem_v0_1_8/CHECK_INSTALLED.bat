@echo off
setlocal
set "APP1=%LOCALAPPDATA%\Programs\ChatVdvoem++\ChatVdvoem++.exe"
set "APP2=%LOCALAPPDATA%\Programs\CHVD++ MultiChat Desktop\ChatVdvoem++.exe"
set "APP2_OLD=%LOCALAPPDATA%\Programs\CHVD++ MultiChat Desktop\CHVD++ MultiChat Desktop.exe"
set "APP3=%LOCALAPPDATA%\Programs\chvd-multichat-desktop\ChatVdvoem++.exe"
set "APP3_OLD=%LOCALAPPDATA%\Programs\chvd-multichat-desktop\CHVD++ MultiChat Desktop.exe"
set "APP4=%PROGRAMFILES%\CHVD++ MultiChat Desktop\ChatVdvoem++.exe"
set "APP4_OLD=%PROGRAMFILES%\CHVD++ MultiChat Desktop\CHVD++ MultiChat Desktop.exe"
if exist "%APP1%" goto found1
if exist "%APP2%" goto found2
if exist "%APP2_OLD%" goto found2_old
if exist "%APP3%" goto found3
if exist "%APP3_OLD%" goto found3_old
if exist "%APP4%" goto found4
if exist "%APP4_OLD%" goto found4_old
echo ChatVdvoem++ was not found in the standard install folders.
echo Run DEBUG_INSTALLER.bat and inspect the NSIS log.
pause
exit /b 1
:found1
start "" "%APP1%"
exit /b 0
:found2
start "" "%APP2%"
exit /b 0
:found3
start "" "%APP3%"
exit /b 0
:found4
start "" "%APP4%"
exit /b 0
:found2_old
start "" "%APP2_OLD%"
exit /b 0
:found3_old
start "" "%APP3_OLD%"
exit /b 0
:found4_old
start "" "%APP4_OLD%"
exit /b 0
