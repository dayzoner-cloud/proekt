@echo off
setlocal
cd /d "%~dp0"
echo === Node ===
where node
echo.
node --version
echo.
echo === npm ===
where npm
where npm.cmd
echo.
node scripts\build.js --diagnose
echo.
pause
